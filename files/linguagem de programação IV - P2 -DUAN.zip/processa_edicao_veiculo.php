<?php
/**
 * arquivo: processa_edicao_veiculo.php
 * recebimento de dados veiculos - questao 4
 */
include 'config.php';

// redirecionar em caso de erro
function redirecionarComErro($erro_msg, $placa_original, $dados_post) {
    // retorna ao formulario com os dados e mensagem de erro que ja foram definidas
    $qs = http_build_query([
        'erro' => $erro_msg,
        'placa' => $placa_original, 
        'modelo' => $dados_post['modelo'],
        'fabricante' => $dados_post['fabricante'],
        'ano' => $dados_post['ano'],
        'cor' => $dados_post['cor']
    ]);
    header("Location: form_edicao_veiculo.php?" . $qs);
    exit;
}

// receber os valores do post  
$placa_original = htmlspecialchars(filter_input(INPUT_POST, 'placa_original')); // Placa usada na clausula WHERE
$modelo = htmlspecialchars(filter_input(INPUT_POST, 'modelo'));
$fabricante = htmlspecialchars(filter_input(INPUT_POST, 'fabricante'));
$ano = htmlspecialchars(filter_input(INPUT_POST, 'ano', FILTER_VALIDATE_INT));
$cor = htmlspecialchars(filter_input(INPUT_POST, 'cor'));

// coleta de dados caso de erro
$dados_post = [
    'modelo' => filter_input(INPUT_POST, 'modelo'),
    'fabricante' => filter_input(INPUT_POST, 'fabricante'),
    'ano' => filter_input(INPUT_POST, 'ano'),
    'cor' => filter_input(INPUT_POST, 'cor')
];

// verificacao de cada atributo do veiculo
if (empty($placa_original) || empty($modelo) || empty($fabricante) || empty($cor) || $ano === false || $ano < 1900) {
    $erro = "Campos de edicao invalidos ou nao preenchidos.";
    redirecionarComErro($erro, $placa_original, $dados_post);
}

$pdo = conectarPDO();

// atualizar os dados do veiculo
try {
    $stmt = $pdo->prepare(SQL_ATUALIZA_VEICULO);
    $stmt->execute([
        ':modelo' => $modelo,
        ':fabricante' => $fabricante,
        ':ano' => $ano,
        ':cor' => $cor,
        ':placa' => $placa_original 
    ]);
    header("Location: index.php");
    exit;

    // colocar erros caso aconteca  
} catch (\PDOException $e) {
    // caso de erro - atualizacao
    error_log("Erro na atualizacao do veiculo: " . $e->getMessage());

    // caso de erro - depois que vai para a pagina que lista os veiculos
    echo "<!DOCTYPE html><html><head><title>Erro</title></head><body>";
    echo "<script>";
    echo "alert('Erro ao atualizar o veiculo: " . addslashes($e->getMessage()) . "');";
    echo "window.location.href = 'index.php';";
    echo "</script>";
    echo "</body></html>";
    exit;
}
?>