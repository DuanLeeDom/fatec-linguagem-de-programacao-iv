<?php
/**
 * arquivo: form_edicao_veiculo.php
 * formuario de edicao dos veiculos - questao 4.
 */
// importar o db
include 'config.php';

// variavel para placa de veiculo
$placa_url = htmlspecialchars(filter_input(INPUT_GET, 'placa'));
$erro_get = htmlspecialchars(filter_input(INPUT_GET, 'erro')) ?: '';
$veiculo = null;
$erro_busca = null;

if (empty($placa_url)) {
    $erro_busca = "placa não fornecida para alterar";
} else {
    $pdo = conectarPDO();
    try {
        // Busca os dados atuais do veiculo
        $stmt_veiculo = $pdo->prepare(SQL_VEICULOS_PLACA);
        $stmt_veiculo->execute([':placa' => $placa_url]);
        $veiculo = $stmt_veiculo->fetch();

        if (!$veiculo) {
            $erro_busca = "Veiculo com placa '{$placa_url}' nao encontrado.";
        }

    } catch (\PDOException $e) {
        error_log("Erro ao buscar veiculo para edicao: " . $e->getMessage());
        $erro_busca = "Falha ao carregar dados do veiculo.";
    }
}

// Se nao houve erro na busca, define as variaveis para preencher o formulario
if ($veiculo) {
    // Preserva os valores antigos ou os valores re-enviados com erro [cite: 19]
    $modelo = htmlspecialchars(filter_input(INPUT_GET, 'modelo')) ?: $veiculo['modelo'];
    $fabricante = htmlspecialchars(filter_input(INPUT_GET, 'fabricante')) ?: $veiculo['fabricante'];
    $ano = htmlspecialchars(filter_input(INPUT_GET, 'ano')) ?: $veiculo['ano'];
    $cor = htmlspecialchars(filter_input(INPUT_GET, 'cor')) ?: $veiculo['cor'];
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Editar Veículo</title>
    <style>
        body { font-family: sans-serif; }
        .erro { color: red; }
        .campo_nao_editavel { color: #666; background-color: #f8f8f8; }
    </style>
</head>
<body>
    <h1>editar informacoes do veiculo</h1>
    <p><a href="index.php">voltar a lista dos veiculos</a></p>

    <?php if ($erro_busca): ?>
        <p class="erro"><?php echo $erro_busca; ?></p>
    <?php elseif ($erro_get): ?>
        <p class="erro">Atenção: <?php echo $erro_get; ?></p>
    <?php elseif ($veiculo): ?>

        <form action="processa_edicao_veiculo.php" method="POST">
            
            <label for="placa">placa - nao pode mudar:</label><br>
            <input type="text" name="placa" id="placa" value="<?php echo htmlspecialchars($veiculo['placa']); ?>" readonly class="campo_nao_editavel"><br><br>
            
            <input type="hidden" name="placa_original" value="<?php echo htmlspecialchars($veiculo['placa']); ?>">

            <label for="quilometragem">quilometragem - nao pode mudar:</label><br>
            <input type="number" name="quilometragem" id="quilometragem" value="<?php echo htmlspecialchars($veiculo['quilometragem']); ?>" readonly class="campo_nao_editavel"><br><br>
            
            <label for="modelo">modelo:</label><br>
            <input type="text" name="modelo" id="modelo" value="<?php echo $modelo; ?>" required><br><br>
            
            <label for="fabricante">fabricante:</label><br>
            <input type="text" name="fabricante" id="fabricante" value="<?php echo $fabricante; ?>" required><br><br>
            
            <label for="ano">ano:</label><br>
            <input type="number" name="ano" id="ano" min="1900" max="<?php echo date('Y') + 1; ?>" value="<?php echo $ano; ?>" required><br><br>
            
            <label for="cor">cor:</label><br>
            <input type="text" name="cor" id="cor" value="<?php echo $cor; ?>" required><br><br>

            <button type="submit">atualizar</button>
        </form>
    <?php endif; ?>
</body>
</html>