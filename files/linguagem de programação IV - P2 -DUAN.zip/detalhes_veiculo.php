<?php
/**
 * arquivo: detalhes_veiculo.php
 * exibe informacoes do veiculo/abastecimentos- questao 3
 */
include 'config.php';

// ele filtra a placa do veiculo por get
$placa = htmlspecialchars(filter_input(INPUT_GET, 'placa'));

$erro = null;
$veiculo = null;
$abastecimentos = [];

if (empty($placa)) {
    $erro = "placa nao fornecida";
} else {
    $pdo = conectarPDO();

    try {
        // busca as informacoes do veiculo
        $tabela_placaVeiculo = $pdo->prepare(SQL_VEICULOS_PLACA);
        $tabela_placaVeiculo->execute([':placa' => $placa]);
        $veiculo = $tabela_placaVeiculo->fetch();

        if (!$veiculo) {
            $erro = "veiculo com placa '{$placa}' nao encontrado";
        } else {
            // buscar todos os veiculo
            $tabela_abastecimentos = $pdo->prepare(SQL_ABASTECIMENTOS_VEICULO);
            $tabela_abastecimentos->execute([':placa' => $placa]);
            $abastecimentos = $tabela_abastecimentos->fetchAll();
        }

    } catch (\PDOException $e) {
        error_log("erro ao buscar detalhes do veiculo: " . $e->getMessage());
        $erro = "falha ao carregar dados do veiculo e abastecimentos";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>detalhes veiculo</title>
    <style>
        body { font-family: sans-serif; }
        .erro { color: red; }
        table { width: auto; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body>
    <h1>detalhes do veiculo</h1>
    <p><a href="index.php">voltar a lista de veiculos</a></p>

    <?php if ($erro): ?>
        <p class="erro"><?php echo $erro; ?></p>
    <?php elseif ($veiculo): ?>
        
        <h2>informacoes do veiculo: <?php echo htmlspecialchars($veiculo['placa']); ?></h2>
        <ul>
            <p>placa - <?php echo htmlspecialchars($veiculo['placa']); ?></p>
            <p>modelo - <?php echo htmlspecialchars($veiculo['modelo']); ?></p>
            <p>fabricante - <?php echo htmlspecialchars($veiculo['fabricante']); ?></p>
            <p>ano - <?php echo htmlspecialchars($veiculo['ano']); ?></p>
            <p>cor - <?php echo htmlspecialchars($veiculo['cor']); ?></p>
            <p>km - <?php echo htmlspecialchars($veiculo['quilometragem']); ?></p>
        </ul>

        <hr>

        <h2>historico de abastecimento</h2>

        <?php if (count($abastecimentos) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>data</th>
                        <th>combustivel</th>
                        <th>litros abastecidos</th>
                        <th>km</th>
                        <th>preco do litro</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($abastecimentos as $abastecimento): ?>
                        <tr>
                            <td><?php echo htmlspecialchars(date('d/m/Y', strtotime($abastecimento['data']))); ?></td>
                            <td><?php echo htmlspecialchars($abastecimento['combustivel_nome']); ?></td>
                            <td><?php echo htmlspecialchars(number_format($abastecimento['litros'], 2, ',', '.')); ?></td>
                            <td><?php echo htmlspecialchars(number_format($abastecimento['km'], 0, ',', '.')); ?></td>
                            <td>$ <?php echo htmlspecialchars(number_format($abastecimento['preco_litro'], 2, ',', '.')); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>nenhum abastecimento registrado do veiculo</p>
        <?php endif; ?>

    <?php endif; ?>
</body>
</html>