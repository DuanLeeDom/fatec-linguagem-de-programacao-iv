<?php
/**
 * arquivo: form_abastecimento.php
 * formulario para o abastecimento - questao 1
 */
include 'config.php';

// Inicializa variaveis para preservar os valores em caso de erro (Questao 1 - 1 ponto) [cite: 19]
$erro = htmlspecialchars(filter_input(INPUT_GET, 'erro')) ?: '';
$placa_selecionada = htmlspecialchars(filter_input(INPUT_GET, 'placa')) ?: '';
$combustivel_selecionado = htmlspecialchars(filter_input(INPUT_GET, 'idCombustivel')) ?: '';
$data_abastecimento = htmlspecialchars(filter_input(INPUT_GET, 'data')) ?: '';
$litros_abastecidos = htmlspecialchars(filter_input(INPUT_GET, 'litros')) ?: '';
$preco_litro = htmlspecialchars(filter_input(INPUT_GET, 'precoLitro')) ?: '';
$km_atual = htmlspecialchars(filter_input(INPUT_GET, 'kmAtual')) ?: '';

$pdo = conectarPDO();
$veiculos = [];
$combustiveis = [];

// busca de veiculos/combustiveis
try {
    $stmt_veiculos = $pdo->query(SQL_VEICULOS_TODOS);
    $veiculos = $stmt_veiculos->fetchAll();
    $stmt_combustiveis = $pdo->query(SQL_COMBUSTIVEIS_TODOS);
    $combustiveis = $stmt_combustiveis->fetchAll();

} catch (\PDOException $e) {
    error_log("Erro ao buscar dados para o formulario: " . $e->getMessage());
    $erro = "Erro ao carregar veiculos/combustiveis do banco.";
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>registro de abastecimento</title>
    <style>
        body { font-family: sans-serif; }
        .erro { color: red; }
    </style>
</head>
<body>
    <h1>registrar abastecimento</h1>
    <p><a href="index.php">voltar para a lista de veiculos</a></p>
    
    <?php if ($erro): ?>
        <p class="erro">atencao: <?php echo $erro; ?></p>
    <?php endif; ?>

    <form action="processa_abastecimento.php" method="POST">

        <label for="placa">placa do veiculo:</label><br>
        <select name="placa" id="placa" required>
            <option value="">selecione um veículo</option>
            <?php foreach ($veiculos as $v): ?>
                <option value="<?php echo htmlspecialchars($v['placa']); ?>"
                        <?php echo ($placa_selecionada == $v['placa']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($v['placa'] . " - " . $v['modelo']); ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <label for="idCombustivel">combustivel:</label><br>
        <select name="idCombustivel" id="idCombustivel" required>
            <option value="">selecione o combustivel</option>
            <?php foreach ($combustiveis as $c): ?>
                <option value="<?php echo htmlspecialchars($c['id']); ?>"
                        <?php echo ($combustivel_selecionado == $c['id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($c['nome']); ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>

        <label for="data">data do abastecimento:></label><br>
        <input type="date" name="data" id="data" value="<?php echo $data_abastecimento; ?>" required><br><br>
        
        <label for="litros">litros abastecidos:</label><br>
        <input type="number" name="litros" id="litros" step="0.01" min="0.01" value="<?php echo $litros_abastecidos; ?>" required><br><br>
        
        <label for="precoLitro">preco por litros $:</label><br>
        <input type="number" name="precoLitro" id="precoLitro" step="0.01" min="0.01" value="<?php echo $preco_litro; ?>" required><br><br>
        
        <label for="kmAtual">atual quilometragem:</label><br>
        <input type="number" name="kmAtual" id="kmAtual" step="1" min="1" value="<?php echo $km_atual; ?>" required><br><br>

        <button type="submit">confirmar o registro</button>
    </form>
</body>
</html>