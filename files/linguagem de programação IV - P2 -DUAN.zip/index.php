<?php
/**
 * arquivo: index.php
 * ponto de entrada principal - questao 2
 */
include 'config.php';

// conexao ao db
$pdo = conectarPDO();

// consulta todos os veiculos cadastrados ai faz verificacao caso nao tenha nehum
try {
    $stmt = $pdo->query(SQL_VEICULOS_TODOS);
    $veiculos = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("erro ao buscar veiculo: " . $e->getMessage());
    $veiculos = [];
    $erro_busca = "erro ao carregar a lista";
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>gestao frota abastecimento</title>
    <style>
        body { font-family: sans-serif; }
        table { width: auto; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #ddd; }
    </style>
</head>
<body>
    <h1>veiculos cadastrados</h1>
    <p><a href="form_abastecimento.php">novo abastecimento</a></p>

    <?php if (isset($erro_busca)): ?>
        <?=  $erro_busca?>
    <?php elseif (count($veiculos) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>placa</th>
                    <th>modelo</th>
                    <th>fabricante</th>
                    <th>ano</th>
                    <th>cor</th>
                    <th>km</th>
                    <th>acoes</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($veiculos as $veiculo): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($veiculo['placa']); ?></td>
                        <td><?php echo htmlspecialchars($veiculo['modelo']); ?></td>
                        <td><?php echo htmlspecialchars($veiculo['fabricante']); ?></td>
                        <td><?php echo htmlspecialchars($veiculo['ano']); ?></td>
                        <td><?php echo htmlspecialchars($veiculo['cor']); ?></td>
                        <td><?php echo htmlspecialchars($veiculo['quilometragem']); ?></td>
                        <td>
                            <a href="detalhes_veiculo.php?placa=<?php echo urlencode($veiculo['placa']); ?>">detalhar</a> |
                            <a href="form_edicao_veiculo.php?placa=<?php echo urlencode($veiculo['placa']); ?>">altera</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>nenhum veiculo achado</p>
    <?php endif; ?>
</body>
</html>