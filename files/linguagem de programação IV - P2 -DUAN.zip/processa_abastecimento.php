<?php
/**
 * arquivo: processa_abastecimento.php
 * recebe dados do formulario e seus procedimentos - questao 1
 */

include 'config.php';
$campos_para_erro = [];
$erro = null;

// redirecinamento caso tenha um erro 
function redirecionarComErro($erro_msg, $dados) {
    $qs = http_build_query([
        'erro' => $erro_msg,
        'placa' => $dados['placa'],
        'idCombustivel' => $dados['idCombustivel'],
        'data' => $dados['data'],
        'litros' => $dados['litros'],
        'precoLitro' => $dados['precoLitro'],
        'kmAtual' => $dados['kmAtual']
    ]);
    header("Location: form_abastecimento.php?" . $qs);
    exit;
}

// recebimento dos dados de post
$placa = htmlspecialchars(filter_input(INPUT_POST, 'placa'));
$idCombustivel = htmlspecialchars(filter_input(INPUT_POST, 'idCombustivel', FILTER_VALIDATE_INT));
$data = htmlspecialchars(filter_input(INPUT_POST, 'data'));
$litros = htmlspecialchars(filter_input(INPUT_POST, 'litros', FILTER_VALIDATE_FLOAT));
$precoLitro = htmlspecialchars(filter_input(INPUT_POST, 'precoLitro', FILTER_VALIDATE_FLOAT));
$kmAtual = htmlspecialchars(filter_input(INPUT_POST, 'kmAtual', FILTER_VALIDATE_INT));

// a coleta dos dados para o envio novamente caso erro a preservacao dos valores
$dados_post = [
    'placa' => $placa,
    'idCombustivel' => filter_input(INPUT_POST, 'idCombustivel'), 
    'data' => $data,
    'litros' => filter_input(INPUT_POST, 'litros'), 
    'precoLitro' => filter_input(INPUT_POST, 'precoLitro'), 
    'kmAtual' => filter_input(INPUT_POST, 'kmAtual') 
];

// verificar se nao estao vazios ou invalidos
if (empty($placa) || empty($idCombustivel) || empty($data) || 
    $litros === false || $litros <= 0 || 
    $precoLitro === false || $precoLitro <= 0 || 
    $kmAtual === false || $kmAtual <= 0) {
    $erro = "campos invalidos/nao preenchidos";
    redirecionarComErro($erro, $dados_post);
}
$valorGasto = $litros * $precoLitro;

// inicia a conexao e depois a transacao
$pdo = conectarPDO();
$pdo->beginTransaction();

try {
// colocar o abastecimento 
    $stmt_abastecimento = $pdo->prepare(SQL_INSERIR_ABASTECIMENTO);
    $stmt_abastecimento->execute([
        ':data' => $data,
        ':placa' => $placa,
        ':idCombustivel' => $idCombustivel,
        ':km' => $kmAtual,
        ':litros' => $litros,
        ':valorgasto' => $valorGasto
    ]);
    // atualiza a km do veiculo
    $stmt_atualiza_km = $pdo->prepare(SQL_ATUALIZA_KM_VEICULO);
    $stmt_atualiza_km->execute([
        ':km' => $kmAtual,
        ':placa' => $placa
    ]);
    $pdo->commit();
    header("Location: index.php");
    exit;
} catch (\PDOException $e) {
    // caso tenha erro, desfaz as operacoes para não prejudicar
    $pdo->rollBack();
    error_log("falha no registro do abastecimento ou atualizacao de km: " . $e->getMessage());
    $erro = "falha ao registrar: " . $e->getMessage();
    redirecionarComErro($erro, $dados_post);
}
?>