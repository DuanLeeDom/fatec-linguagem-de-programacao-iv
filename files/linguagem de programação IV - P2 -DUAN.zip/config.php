<?php
/**
 * arquivo: config.php
 * funcoes de configuracao e conexao com o banco de dados 
 */ 

// aqui o auxiliar de conexao e constantes mysql que usarei nos demais arquivos
const SQL_VEICULOS_TODOS = "SELECT * FROM veiculo";
const SQL_VEICULOS_PLACA = "SELECT * FROM veiculo WHERE placa = :placa"; 
const SQL_COMBUSTIVEIS_TODOS = "SELECT id, nome FROM combustivel"; 

const SQL_INSERIR_ABASTECIMENTO = "INSERT INTO abastecimento (data, placa, idCombustivel, km, litros, valorgasto) VALUES (:data, :placa, :idCombustivel, :km, :litros, :valorgasto)"; 

const SQL_ATUALIZA_KM_VEICULO = "UPDATE veiculo SET quilometragem = :km WHERE placa = :placa";

// calculo do preco
const SQL_ABASTECIMENTOS_VEICULO = "SELECT 
    a.data, 
    a.litros, 
    a.km, 
    (a.valorgasto / a.litros) AS preco_litro, 
    c.nome AS combustivel_nome 
FROM abastecimento a 
JOIN combustivel c ON a.idCombustivel = c.id 
WHERE a.placa = :placa 
ORDER BY a.data DESC";

const SQL_ATUALIZA_VEICULO = "UPDATE veiculo SET modelo = :modelo, fabricante = :fabricante, ano = :ano, cor = :cor WHERE placa = :placa";

/**
 * conectar ao banco de dados
 * @return PDO objeto de conexao
 */
function conectarPDO() {
    $host = '127.0.0.1';
    $dbname = 'gestaofrota';
    $usuario = 'root';
    $senha = '';
    $charset = 'utf8';

    $dsn = "mysql:host=$host; dbname=$dbname; charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, 
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,     
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        $pdo = new PDO($dsn, $usuario, $senha, $options);
        return $pdo;
    } catch (\PDOException $e) {
        error_log("erro de conexao: " . $e->getMessage());
        die("erro ao se conectar ao banco");
    }
}
?>