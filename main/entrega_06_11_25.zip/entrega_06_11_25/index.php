<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Sistema de Gestão de Visitantes</title>
</head>
<body>
    <h1>Bem-vindo ao Sistema de Gestão de Visitantes</h1>
    <ul>
        <li><a href="visitante.php">Cadastrar Visitante</a></li>
        <li><a href="insereData.php">Registrar Data de Visita</a></li>
    </ul>
</body>
</html>
